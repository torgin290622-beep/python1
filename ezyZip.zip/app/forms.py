from django import forms
from .models import Sportshy

class SportshyForm(forms.ModelForm):
    class Meta:
        model = Sportshy
        fields = ["at", "zhas"]
