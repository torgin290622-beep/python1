
import random
import numpy as np
import matplotlib.pyplot as plt
import sqlite3

class Sportshy:
    def __init__(self, at, uakyt, zhas):
        self.at = at
        self.uakyt = uakyt
        self.zhas = zhas

    def info(self):
        return f"{self.at} - Жасы: {self.zhas}, Уақыты: {self.uakyt} сек"


class NatizhelerManager:
    def __init__(self):
        self.natizheler = {}
        self.db_connect()

    def db_connect(self):
        self.conn = sqlite3.connect("sportshy.db")
        self.cursor = self.conn.cursor()

        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS sportshy (
                at TEXT PRIMARY KEY,
                uakyt REAL,
                zhas INTEGER
            )
        """)
        self.conn.commit()

    def db_save_all(self):
        self.cursor.execute("DELETE FROM sportshy")

        for s in self.natizheler.values():
            self.cursor.execute("""
                INSERT INTO sportshy (at, uakyt, zhas)
                VALUES (?, ?, ?)
            """, (s.at, s.uakyt, s.zhas))

        self.conn.commit()
        print("SQLite дерекқорына сақталды.")

    def db_load(self):
        self.cursor.execute("SELECT at, uakyt, zhas FROM sportshy")
        rows = self.cursor.fetchall()

        for at, uakyt, zhas in rows:
            self.natizheler[at] = Sportshy(at, float(uakyt), int(zhas))

        if rows:
            print("SQLite дерекқорынан жүктелді.")
        else:
            print("База бос.")

    def add_sportshy(self):
        try:
            at = input("Жаңа спортшы аты: ")
            uakyt = round(random.uniform(10, 100), 2)
            zhas = int(input("Жасы: "))

            self.natizheler[at] = Sportshy(at, uakyt, zhas)
            print(at, "қосылды.")
        except ValueError:
            print("Қате! Жас санмен болуы керек.")

    def show_results(self):
        if not self.natizheler:
            print("Мәліметтер жоқ!")
            return

        print("Барлық спортшылар:")
        for s in self.natizheler.values():
            print(s.info())

        ortasha_uakyt = sum(s.uakyt for s in self.natizheler.values()) / len(self.natizheler)
        print("Орташа уақыт:", int(ortasha_uakyt * 10) / 10, "секунд")


        results = []
        for s in self.natizheler.values():
            results.append((s.at, s.uakyt, s.zhas))

        for i in range(len(results)):
            for j in range(i + 1, len(results)):
                if results[i][1] > results[j][1]:
                    results[i], results[j] = results[j], results[i]


        print("Топ-3 үздік спортшы:")
        for i in range(min(3, len(results))):
            name, uakyt, zhas = results[i]
            print(i + 1, ".", name, "-", uakyt, "сек,", "Жасы:", zhas)

        print("График түрінде нәтижелер:")
        max_time = max(s.uakyt for s in self.natizheler.values())
        for s in self.natizheler.values():
            uzun = int((s.uakyt / max_time) * 40)
            print(s.at.ljust(10) + ": " + "█" * uzun + " " + str(s.uakyt) + " сек")

    def find_sportshy(self):
        izdeu = input("Қай спортшыны іздегіңіз келеді? ")
        for name in self.natizheler:
            if name.lower() == izdeu.lower():
                print(izdeu, "жарысқа қатысады!")
                return
        print(izdeu, "тізімде жоқ.")

    def save_to_file(self, filename="natizheler.txt"):
        try:
            with open(filename, "w") as f:
                for s in self.natizheler.values():
                    f.write(f"{s.at},{s.uakyt},{s.zhas}\n")
            print("Файлға сақталды.")
        except Exception as e:
            print("Файлға сақтау кезінде қате:", e)

    def load_from_file(self, filename="natizheler.txt"):
        try:
            with open(filename, "r") as f:
                for line in f:
                    at, uakyt, zhas = line.strip().split(",")
                    self.natizheler[at] = Sportshy(at, float(uakyt), int(zhas))
            print("Файлдан жүктелді.")
        except FileNotFoundError:
            print("Файл табылмады.")

    def statistika_numpy(self):
        if not self.natizheler:
            print("Статистика жасау үшін мәлімет жоқ!")
            return

        vals = np.array([s.uakyt for s in self.natizheler.values()])
        print("\nNumPy статистикасы:")
        print("Қосынды:", np.sum(vals))
        print("Орташа:", np.mean(vals))
        print("Максимум:", np.max(vals))
        print("Минимум:", np.min(vals))

    def grafik_salu(self):
        if not self.natizheler:
            print("Мәлімет жоқ!")
            return

        categories = list(self.natizheler.keys())
        values = [s.uakyt for s in self.natizheler.values()]

        plt.figure(figsize=(8, 5))
        plt.bar(categories, values, edgecolor='black', color='yellow')
        plt.title("Спортшылардың жүзу уақыты")
        plt.xlabel("Спортшылар")
        plt.ylabel("Уақыты (сек)")
        plt.grid(True)
        plt.show()




def main():
    print("ЖҮЗУ ЖАРЫСЫ БАҒДАРЛАМАСЫ")
    natizheler = NatizhelerManager()

    natizheler.load_from_file()
    natizheler.db_load()

    while True:
        print("\nМәзір:")
        print("1. Спортшы қосу")
        print("2. Барлық нәтижелерді көру")
        print("3. Спортшы іздеу")
        print("4. Мәліметтерді файлға және базаға сақтау")
        print("5. NumPy статистикасы")
        print("6. График салу (Matplotlib)")
        print("7. Шығу")

        tandau = input("Таңдаңыз: ").strip()

        if tandau == "1":
            natizheler.add_sportshy()

        elif tandau == "2":
            natizheler.show_results()

        elif tandau == "3":
            natizheler.find_sportshy()

        elif tandau == "4":
            natizheler.save_to_file()
            natizheler.db_save_all()

        elif tandau == "5":
            natizheler.statistika_numpy()

        elif tandau == "6":
            natizheler.grafik_salu()

        elif tandau == "7":
            print("Бағдарлама аяқталды.")
            break

        else:
            print("Қате таңдау!")


if __name__ == "__main__":
    main()
