from django.contrib import admin
from .models import Sportshy

@admin.register(Sportshy)
class SportshyAdmin(admin.ModelAdmin):
    list_display = ("at", "uakyt", "zhas")
    search_fields = ("at",)


# Register your models here.
