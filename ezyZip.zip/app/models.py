from django.db import models

class Sportshy(models.Model):
    at = models.CharField(max_length=100, primary_key=True)
    uakyt = models.FloatField()
    zhas = models.IntegerField()

    def __str__(self):
        return f"{self.at} - {self.zhas} жас, {self.uakyt} сек"


# Create your models here.
