from django.shortcuts import render, redirect
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io
import base64
import random
import sqlite3


DB_PATH = "sportshy.db"

class Sportshy:
    def __init__(self, at, uakyt, zhas):
        self.at = at
        self.uakyt = uakyt
        self.zhas = zhas

def get_all_sportshy():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sportshy (
            at TEXT PRIMARY KEY,
            uakyt REAL,
            zhas INTEGER
        )
    """)
    cursor.execute("SELECT at, uakyt, zhas FROM sportshy")
    rows = cursor.fetchall()
    conn.close()
    return [Sportshy(at, float(uakyt), int(zhas)) for at, uakyt, zhas in rows]

def save_sportshy(at, zhas):
    uakyt = round(random.uniform(10, 100), 2)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT OR REPLACE INTO sportshy (at, uakyt, zhas) VALUES (?, ?, ?)", (at, uakyt, zhas))
    conn.commit()
    conn.close()

def main_page(request):
    if request.method == "POST":
        at = request.POST.get("at")
        zhas = request.POST.get("zhas")
        if at and zhas:
            try:
                zhas = int(zhas)
                save_sportshy(at, zhas)
            except ValueError:
                pass
        return redirect("/")

    sportshy_list = get_all_sportshy()

    # Орташа уақыт есептеу
    ortasha_uakyt = None
    if sportshy_list:
        ortasha_uakyt = sum(s.uakyt for s in sportshy_list) / len(sportshy_list)
        ortasha_uakyt = int(ortasha_uakyt * 10) / 10  # бір ондыққа дейін

    # Топ-3 үздік спортшы (ең аз уақыт бойынша)
    top3 = sorted(sportshy_list, key=lambda s: s.uakyt)[:3]

    # График жасау
    img_base64 = None
    if sportshy_list:
        plt.figure(figsize=(8, 5))
        names = [s.at for s in sportshy_list]
        values = [s.uakyt for s in sportshy_list]
        plt.bar(names, values, color='blue', edgecolor='black')
        plt.title("Спортшылардың нәтижелері")
        plt.xlabel("Спортшылар")
        plt.ylabel("Уақыты (сек)")
        plt.tight_layout()
        buffer = io.BytesIO()
        plt.savefig(buffer, format="png")
        plt.close()
        buffer.seek(0)
        img_base64 = base64.b64encode(buffer.getvalue()).decode()

    return render(request, "main.html", {
        "sportshy_list": sportshy_list,
        "ortasha_uakyt": ortasha_uakyt,
        "top3": top3,
        "img": img_base64
    })
